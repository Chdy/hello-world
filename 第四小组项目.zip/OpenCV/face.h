#pragma once
class face
{
public:
	face();
	~face();
};

